package com.example.catalog_server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class catalogserverTests {

    @Test
    void contextLoads() {
    }

}
