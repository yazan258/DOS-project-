package com.example.order_server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderServerApplicationTests {

    @Test
    void contextLoads() {
    }

}
